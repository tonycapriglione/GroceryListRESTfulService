package com.ironyard.springboot.controller;

import java.util.Collection;
import java.util.HashMap;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ironyard.springboot.data.GroceryItem;

@RestController
public class GroceryController {
	
	private HashMap<String, GroceryItem> tempStore = new HashMap<String, GroceryItem>();
	
	/**
	 * Create the specified GroceryItem
	 * @param createThis
	 * @return populated GroceryItem
	 */
	@RequestMapping(value = "/groceryitems", method = RequestMethod.POST)
	public GroceryItem create(@RequestBody GroceryItem createThis){
		// store it
		tempStore.put(createThis.getName(), createThis);
		return createThis;
	}
	
	/**
	 * Get the specified GroceryItem
	 * @param id
	 * @return requested GroceryItem
	 */
	@RequestMapping(value = "/groceryitems/{name}", method = RequestMethod.GET)
	public GroceryItem get(@PathVariable String name){
		// set ID
		return tempStore.get(name);
	}
	
	
	/**
	 * 
	 * @return Collection of all GroceryItems
	 */
	@RequestMapping(value = "/groceryitems", method = RequestMethod.GET)
	public Collection<GroceryItem> get() {
		// set ID
		return tempStore.values();
	}
	
	/**
	 * Deletes the specified GroceryItem
	 * @param createThis
	 * @return "Deleted Succesfully"
	 */
	@RequestMapping(value = "/groceryitems", method = RequestMethod.DELETE)
	public String delete(@RequestBody GroceryItem deleteThis){
		tempStore.remove(deleteThis.getName());
		return "Deleted Succesfully";
	}
}
