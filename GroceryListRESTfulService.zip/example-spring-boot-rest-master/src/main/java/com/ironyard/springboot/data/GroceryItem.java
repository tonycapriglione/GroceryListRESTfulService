package com.ironyard.springboot.data;

public class GroceryItem {
	
	private String name;
	private String isle;
	private double price;
	private long quantity;
	
	
	public String getName() {
		return name;
	}
	public String getIsle() {
		return isle;
	}
	public void setIsle(String isle) {
		this.isle = isle;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public long getQuantity() {
		return quantity;
	}
	public void setQuantity(long quantity) {
		this.quantity = quantity;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}
